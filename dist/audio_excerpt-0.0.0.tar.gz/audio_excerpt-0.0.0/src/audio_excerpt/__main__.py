from . import main

main.script()
