# extract audio excerpt 


## installation 

### prerequisites

* ffmpeg
* python install
* execute git clone -