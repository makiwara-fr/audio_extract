# extract audio excerpt 


## installation 

### prerequisites

* ffmpeg
* python install
* pip install audio_excerpt